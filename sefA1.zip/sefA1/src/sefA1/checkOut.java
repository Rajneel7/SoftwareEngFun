package sefA1;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/*
 * This class processes the contents of the shopping basket. It requires a
 * reference to the ShoppingBasket and CurrentDealsList, which can be done
 * statically, but I've added field variables for legibility
 */

public class checkOut {

}