package sefA1;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Scanner;

import org.junit.jupiter.api.Test;

class mainmenuTest {

	@Test

	public void TestaddMethod() {
		ArrayList<Product> array = new ArrayList<Product>();
	}

	public void addItem(Product array) {
		System.out.println("Selected adding function");

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter item ID");

		int ID = sc.nextInt();

		System.out.println("Enter item name");
		String name = sc.next();

		System.out.println("Enter item price");
		double price = sc.nextDouble();

		Product item = new Product();

		item.ID = ID;
		item.name = name;
		item.price = price;
		array.add(item);
		System.out.println("Item has been added");

	}
}
