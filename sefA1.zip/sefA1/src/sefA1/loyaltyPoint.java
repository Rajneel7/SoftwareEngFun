package sefA1;

public class loyaltyPoint {

}
