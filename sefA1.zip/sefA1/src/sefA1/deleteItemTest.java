package sefA1;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Scanner;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
class deleteItemTest {

	@Test
 
    public void testaddPrice(){
		


}}
