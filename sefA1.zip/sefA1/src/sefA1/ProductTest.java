package sefA1;

import java.io.IOException; 
import java.util.Scanner; 
  
public class ProductTest { 
 public static void main(String[] args) throws IOException { 
 Scanner sc = new Scanner(System.in); 
 shopper shopper = new shopper(); 
 manager manager = new manager(); 
   
 while(true){ 
  System.out.println( "    Welcome to our store"); 
  System.out.println("Enter your role (1.Customer 2.Manager 3.Quit)"); 
  int choice = sc.nextInt(); 
  switch(choice){ 
  case 1: 
  //顾客 
  shopper.shop(); 
  break; 
  case 2: 
  //管理员 
  manager.manager(); 
  break; 
  case 3: 
  System.exit(0); 
  default: 
  System.out.println("Wrong role"); 
  } 
 } 
   
 } 
} 